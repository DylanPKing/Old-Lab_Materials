#include <iostream>
#include <string>
#include <sstream>
#include <math.h>
#include <list>
#include <vector>

class nonZero
{
public:
	int column;
	double value;
	nonZero(int column, double value) : column(column), value(value) {}
};


int main(int argc, char *argv[])
{
	if (argc == 2 || argc > 3)
	{
		std::cerr << "Usage: matz (-e int)" << std::endl;
		exit(1); 
	}
	std::vector< std::vector<nonZero> > members;
	std::string matLine;
	float limit = ((argc == 3 && std::string(argv[1]).compare("-e") == 0) ? atof(argv[2]) : 0);
	while (std::getline(std::cin, matLine))
	{
		std::vector<nonZero> mRow;
		std::istringstream lstream(matLine);
		int col = 0;
		double val = 0.0;
		while (lstream >> col >> val)
		{
			nonZero n(col, val);
			mRow.push_back(n);
		}
		members.push_back(mRow);
	}
	
	/*
	for (int i = 0; i < members.size(); ++i)
	{
		for (int j = 0; j < members[i].size(); ++j)
		{
			std::cout << members[i][j].column << " " << members[i][j].value << " ";
		}
		std::cout << std::endl;
	}
	*/
	
	std::vector< std::vector<nonZero> > tMem;
	for (int i = 0; i < members.size(); ++i)
	{
		std::vector<nonZero> row;
		tMem.push_back(row);
	}
	
	for (int i = 0; i < members.size(); ++i)
	{
		std::vector<nonZero> tempRow = members[i];
		std::cout << "row made" << std::endl;
		for (int j = 0; j < tempRow.size(); ++j)
		{
			std::cout << "entered loop " << std::endl;
			std::cout << (tempRow[j].column - 1) << std::endl;
			std::vector<nonZero> tempTRow = tMem[tempRow[j].column - 1];
			std::cout << "t row made" << std::endl;
			nonZero n(i + 1, tempRow[j].value);
			std::cout << "value read" << std::endl;
			tempTRow.push_back(n);
			std::cout << "value added" << std::endl;
			tMem[tempRow[j].column - 1] = tempTRow;
			std::cout << "row added" << std::endl;
		}
	}
	
	for (int i = 0; i < tMem.size(); ++i)
	{
		for (int j = 0; j < tMem[i].size(); ++j)
		{
			std::cout << tMem[i][j].column << " " << tMem[i][j].value << " ";
		}
		if (i != tMem.size() - 1)
			std::cout << std::endl;
	}
}
