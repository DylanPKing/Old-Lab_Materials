#include <iostream>
#include <sstream>
#include <vector>
#include <cmath>

#define MIN(a,b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? (a) : (b))

class nonZero
{
public:
	int column;
	double value;
	nonZero(int column, double value) : column(column), value(value) {}
};

typedef std::vector<nonZero> matRow;
typedef std::vector<matRow> matrix;

void readMat(matrix& members, int& cols)
{
	std::string matLine;
	while (std::getline(std::cin, matLine))
	{
		matRow mRow;
		std::istringstream lstream(matLine);
		int col = 0;
		double val = 0.0;
		while (lstream >> col >> val)
		{
			nonZero n(col, val);
			mRow.push_back(n);
			cols = (cols < col) ? col : cols;
		}
		members.push_back(mRow);
	}
}

void generateMatrixSize(matrix& mat, const int& cols)
{
	for (int i = 0; i < cols; ++i)
	{
		matRow row;
		mat.push_back(row);
	}
}

void transposeMat(const matrix& members, matrix& tMem)
{
	for (int i = 0; i < members.size(); ++i)
	{
		matRow tempRow = members[i];
		for (int j = 0; j < tempRow.size(); ++j)
		{
			matRow& tempTRow = tMem[tempRow[j].column - 1];
			nonZero n(i + 1, tempRow[j].value);
			tempTRow.push_back(n);
		}
	}
}

double dotProd(const matRow& r1, const matRow& r2)
{
	matRow::const_iterator it1 = r1.begin(), e1 = r1.end();
	matRow::const_iterator it2 = r2.begin(), e2 = r2.end();

	double dp = 0;
	while (1)
	{
		int targetCol = MAX(it1->column, it2->column);

		while (it1->column < targetCol && it1 != e1)
			it1++;
		if (it1 == e1)
			break;
		while (it2->column < targetCol && it2 != e2)
			it2++;
		if (it2 == e2)
			break;
		if (it1->column == it2->column)
		{
			dp += it1->value * it2->value; // we finally found a macthing pair
			// fprintf(stderr, "Updating dp with %.2f*%.2f (k=%d)\n", it1->getVal(), it2->getVal(),  it2->getInd());
			it1++;			// this is arbitrary
			if (it1 == e1)
				break;	// reached end of 
		}
	}
	return dp;
}

void calculatePower(matrix& members, matrix& tMem, matrix& powerMat, const int& power)
{
	powerMat.clear();
	/*for (int i = 2; i <= power; ++i)
	{
		for (int j = 0; j < members.size(); ++j)
		{
			matRow& mRow = members[j];
			matRow& tRow = tMem[j];
			matRow& pRow = powerMat[j];
			for (int k = 0; k < members[j].size(); ++k)
			{
				nonZero& n = mRow[k];
				if (i == 2)
					pRow.push_back(nonZero(0, 0.0));
				nonZero& p = pRow[k];
				for (int l = 0; l < tMem[j].size(); ++l)
				{
					nonZero& m = tRow[l];
					if (n.column == m.column)
					{
						pRow[k].column = (pRow[k].column != n.column) ? n.column : pRow[k].column;
						pRow[k].value += n.value * m.value;
					}
				}
			}
		}
	}*/
	for (int i = 2; i <= power; ++i)
	{
		int rind1, rind2;
		matrix::const_iterator rit1; // we only want to /read/ list
		for (rit1 = members.begin(), rind1 = 1; rit1 != members.end(); rit1++, rind1++)
		{
			matrix::const_iterator rit2; // we only want to /read/ list
			for (rit2 = tMem.begin(), rind2 = 1; rit2 != tMem.end(); rit2++, rind2++)
			{
				//      cerr<< "["<< rind1<<", "<< rind2<< "]"<< endl;
				double val = dotProd(*rit1, *rit2); // the two rows
				if (0 < fabs(val))
					powerMat[rind1-1].push_back(nonZero(rind2, val));
			}
		}
	}
	if (power == 0)
	{
		for (int i = 0; i < members.size(); ++i)
		{
			matRow& pRow = powerMat[i];
			pRow.push_back(nonZero(i + 1, 1));
		}
	}
}

void printMat(const matrix& matOut)
{
	for (int i = 0; i < matOut.size(); ++i)
	{
		for (int j = 0; j < matOut[i].size(); ++j)
			std::cout << matOut[i][j].column << " " << matOut[i][j].value << " ";
		if (i != matOut.size() - 1)
			std::cout << std::endl;
	}
}

int main(int argc, char *argv[])
{
	if (argc != 2)
	{
		std::cerr << "Usage: mpow int" << std::endl;
		exit(1);
	}
	int power = atoi(argv[1]);
	if (power < 0)
	{
		std::cerr << "Illegal exponent; exiting." << std::endl;
		exit(1);
	}
	matrix members;
	int cols = 0;
	readMat(members, cols);
	matrix tMem;
	generateMatrixSize(tMem, cols);
	transposeMat(members, tMem);
	if (members.size() != tMem.size())
	{
		std::cerr << "Error: Must use a square matrix." << std::endl;
		exit(1);
	}
	matrix powerMat;
	if (power != 1)
	{
		generateMatrixSize(powerMat, members.size());
		calculatePower(members, tMem, powerMat, power);
		printMat(powerMat);
		exit(0);
	}
	printMat(members);
}
